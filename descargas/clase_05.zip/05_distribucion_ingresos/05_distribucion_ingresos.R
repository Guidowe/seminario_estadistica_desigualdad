## -----------------------------------------------------------------------------------------
#| label: setup
#| message: false
#| warning: false

library(tidyverse)
library(readxl)
library(ggthemes)       # temas visuales para ggplot
library(ggridges)       # densidades apiladas
library(plotly)         # gráficos interactivos
library(reldist)        # Gini ponderado


## -----------------------------------------------------------------------------------------
individual_25_t1 <- read.table("bases_eph/usu_individual_T125.txt",
                               sep = ";", dec = ",", header = TRUE, fill = TRUE)


## -----------------------------------------------------------------------------------------
aglomerados <- read_excel("bases_eph/Aglomerados y Regiones EPH.xlsx")

# parámetro skip = 1, para saltear una fila
regiones <- read_excel("bases_eph/Aglomerados y Regiones EPH.xlsx",
                       sheet = "Regiones EPH", skip = 1)

salario_y_no_registro <- individual_25_t1 %>%
  filter(ESTADO == 1, CAT_OCUP == 3) %>%
  group_by(ANO4, TRIMESTRE, REGION, AGLOMERADO) %>%
  summarise(tasa_no_reg  = sum(PONDERA[PP07H == 2]) / sum(PONDERA),
            salario_prom = weighted.mean(P21, PONDIIO),
            asalariados  = sum(PONDERA),
            .groups = "drop") %>%
  left_join(aglomerados, by = "AGLOMERADO") %>%
  left_join(regiones,    by = "REGION")

salario_y_no_registro


## -----------------------------------------------------------------------------------------
#| echo: false

ggplot(data = salario_y_no_registro,
       aes(x = salario_prom,
           y = tasa_no_reg,
           size = asalariados,
           color = Region)) +
  geom_point() +
  labs(title = "Salario promedio y tasa de no registro por aglomerados",
       subtitle = "31 Aglomerados. 1er Trimestre de 2025.",
       x = "Salario promedio",
       y = "Tasa de no registro") +
  theme_minimal() +
  guides(size = "none") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_x_continuous(labels = scales::number_format(big.mark = ".", decimal.mark = ","))


## -----------------------------------------------------------------------------------------
capa1 <- ggplot(data = salario_y_no_registro,
                aes(x = salario_prom,
                    y = tasa_no_reg,
                    size = asalariados,
                    color = Region))

capa1


## -----------------------------------------------------------------------------------------
capa2 <- capa1 +
  geom_point()

capa2


## -----------------------------------------------------------------------------------------
capa3 <- capa2 +
  labs(title = "Salario promedio y tasa de no registro por aglomerados",
       subtitle = "31 Aglomerados. 1er Trimestre de 2025.",
       x = "Salario promedio",
       y = "Tasa de no registro")

capa3


## -----------------------------------------------------------------------------------------
grafico_final <- capa3 +
  theme_minimal() +
  guides(size = "none") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_x_continuous(labels = scales::number_format(big.mark = ".", decimal.mark = ","))

grafico_final


## -----------------------------------------------------------------------------------------
# ggsave(filename = "Resultados/grafico_aglomerados.png",
#        plot = grafico_final,
#        width = 8, height = 5)


## -----------------------------------------------------------------------------------------
base_para_otros_ejemplos <- individual_25_t1 %>%
  mutate(PONDIIO = as.numeric(PONDIIO)) %>%  # Para evitar Integer Overflow
  filter(P21 > 0) %>%
  mutate(Sexo = case_when(CH04 == 1 ~ "Varón",
                          CH04 == 2 ~ "Mujer"))


## -----------------------------------------------------------------------------------------
ggplot(base_para_otros_ejemplos, aes(x = P21, weight = PONDIIO)) +
  geom_histogram(fill = "salmon", color = "grey25") +
  scale_x_continuous(limits = c(0, 3000000),
                     labels = scales::number_format(big.mark = ".", decimal.mark = ",")) +
  labs(title = "Distribución del ingreso de la ocupación principal",
       subtitle = "Total aglomerados EPH. 1er trimestre de 2025.",
       x = "Ingreso de la ocupación principal", y = "Casos (ponderados)") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ggplot(base_para_otros_ejemplos, aes(x = P21, weight = PONDIIO)) +
  geom_density(fill = "salmon", color = "grey25") +
  scale_x_continuous(limits = c(0, 3000000),
                     labels = scales::number_format(big.mark = ".", decimal.mark = ",")) +
  labs(x = "Ingreso de la ocupación principal", y = "Densidad") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ggplot(base_para_otros_ejemplos, aes(x = P21, weight = PONDIIO)) +
  geom_density(adjust = 2, fill = "salmon", color = "grey25") +
  scale_x_continuous(limits = c(0, 3000000),
                     labels = scales::number_format(big.mark = ".", decimal.mark = ",")) +
  labs(x = "Ingreso de la ocupación principal", y = "Densidad") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ggplot(base_para_otros_ejemplos, aes(x = P21, weight = PONDIIO)) +
  geom_density(adjust = 0.01, fill = "salmon", color = "grey25") +
  scale_x_continuous(limits = c(0, 3000000),
                     labels = scales::number_format(big.mark = ".", decimal.mark = ",")) +
  labs(x = "Ingreso de la ocupación principal", y = "Densidad") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ggplot(base_para_otros_ejemplos, aes(x = P21, y = Sexo, fill = Sexo)) +
  geom_density_ridges(alpha = 0.7) +
  scale_x_continuous(limits = c(0, 3000000),
                     labels = scales::number_format(big.mark = ".", decimal.mark = ",")) +
  labs(title = "Distribución del ingreso de la ocupación principal, según sexo",
       subtitle = "Total aglomerados EPH. 1er trimestre de 2025.",
       x = "Ingreso de la ocupación principal", y = NULL) +
  guides(fill = "none") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ingresos_fuente_reconstruyo <- individual_25_t1 %>%
  mutate(PONDII = as.numeric(PONDII)) %>%   # Para evitar Integer Overflow
  filter(P47T > 0, PONDII > 0) %>%           # Personas con ingreso total positivo
  # Reconstruimos las variables que desde 2024 4T vienen desagregadas
  mutate(V2_M  = V2_01_M + V2_02_M + V2_03_M,     # jubilaciones y pensiones
         V5_M  = V5_01_M + V5_02_M + V5_03_M,     # AUH, planes y ayudas sociales
         V11_M = V11_01_M + V11_02_M,             # becas de estudio
         V21_M = V21_01_M + V21_02_M + V21_03_M,  # aguinaldo de jubilaciones
         V22_M = V22_01_M + V22_02_M + V22_03_M)  # retroactivo de jubilaciones

ingresos_fuente <- ingresos_fuente_reconstruyo %>%
  mutate(PP08J1 = ifelse(is.na(PP08J1), yes = 0, no = PP08J1),
         PP08J2 = ifelse(is.na(PP08J2), yes = 0, no = PP08J2),
         PP08J3 = ifelse(is.na(PP08J3), yes = 0, no = PP08J3),
         itl  = TOT_P12 + P21 + PP08J1 + PP08J2 + PP08J3,
         inl  = V2_M + V3_M + V4_M + V5_M + V8_M + V9_M + V10_M + V11_M +
                V12_M + V18_M + V19_AM + V21_M + V22_M,
         i_polsoc      = V2_M + V4_M + V5_M + V11_M + V21_M + V22_M,
         i_jubila      = V2_M + V21_M + V22_M,
         i_otros_nolab = V3_M + V8_M + V9_M + V10_M + V12_M + V18_M + V19_AM,
         Sexo = case_when(CH04 == 1 ~ "Varón",
                          CH04 == 2 ~ "Mujer"))


## -----------------------------------------------------------------------------------------
composicion_sexo <- ingresos_fuente %>%
  group_by(Sexo) %>%
  summarise(Laborales            = sum(itl * PONDII),
            `Políticas sociales` = sum(i_polsoc * PONDII),
            `Otros no laborales` = sum(i_otros_nolab * PONDII),
            .groups = "drop") %>%
  pivot_longer(cols = -Sexo, names_to = "fuente", values_to = "masa") %>%
  group_by(Sexo) %>%
  mutate(participacion = masa / sum(masa)) %>%
  ungroup() %>%
  mutate(fuente = factor(fuente, levels = c("Otros no laborales",
                                            "Políticas sociales",
                                            "Laborales")))

composicion_sexo

ggplot(composicion_sexo, aes(x = Sexo, y = participacion, fill = fuente)) +
  geom_col(width = 0.6) +
  geom_text(aes(label = scales::percent(participacion, accuracy = 1)),
            position = position_stack(vjust = 0.5),
            color = "white", size = 3.5) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_fill_manual(values = c("Laborales"            = "#45818e",
                               "Políticas sociales"   = "#CA225E",
                               "Otros no laborales"   = "grey50"),
                    breaks = c("Laborales", "Políticas sociales",
                               "Otros no laborales")) +
  coord_flip() +
  labs(title = "Composición del ingreso total individual según fuente, por sexo",
       subtitle = "Personas con ingresos. Total aglomerados EPH. 1er trimestre de 2025.",
       x = NULL, y = "% de la masa de ingreso total", fill = NULL) +
  theme_minimal() +
  theme(legend.position = "bottom")


## -----------------------------------------------------------------------------------------
summary(individual_25_t1$P21)


## -----------------------------------------------------------------------------------------
individual_25_t1 %>%
  filter(P21 == -9) %>%   # Filtro los casos -9
  select(P21, PONDIIO) %>% # Sólo me quedo con las variables P21 y PONDIIO
  unique()                 # ¿Qué valores únicos hay?


## -----------------------------------------------------------------------------------------
# Randomización de números basada en una distribución uniforme entre "min" y "max"
runif(n = 10, min = -0.99, max = 0.99)


## -----------------------------------------------------------------------------------------
runif(n = 10, min = -0.99, max = 0.99)


## -----------------------------------------------------------------------------------------
set.seed(9999) # Semilla
runif(10, min = 0.01, max = 0.99)

set.seed(9999) # Semilla
runif(10, min = 0.01, max = 0.99)


## -----------------------------------------------------------------------------------------
set.seed(9999) # Semilla

base_con_quintiles <- individual_25_t1 %>%
  mutate(PONDIIO = as.numeric(PONDIIO)) %>% # Para evitar Integer Overflow
  filter(ESTADO == 1, P21 > 0) %>%
  mutate(P21_p = P21 + runif(nrow(.),
                             min = -0.99,
                             max = 0.99)) %>%
  mutate(quintil = statar::xtile(x = P21_p,
                                 n = 5,
                                 wt = PONDIIO))


## -----------------------------------------------------------------------------------------
resultado <- base_con_quintiles %>%
  group_by(quintil) %>%
  summarise(casos             = n(),
            casos_pondera     = sum(PONDIIO),
            tasa_feminizacion = sum(PONDIIO[CH04 == 2]) / sum(PONDIIO),
            ingreso_prom      = weighted.mean(x = P21, w = PONDIIO),
            masa_ingresos     = sum(P21 * PONDIIO),
            .groups = "drop") %>%
  mutate(part_masa = masa_ingresos / sum(masa_ingresos))

resultado


## -----------------------------------------------------------------------------------------
brecha <- resultado %>%
  summarise(ingreso_q1 = ingreso_prom[quintil == 1],
            ingreso_q5 = ingreso_prom[quintil == 5],
            brecha_5_1 = ingreso_q5 / ingreso_q1)

brecha


## -----------------------------------------------------------------------------------------
ggplot(resultado, aes(x = factor(quintil), y = tasa_feminizacion)) +
  geom_col(fill = "steelblue") +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "grey40") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(title = "Tasa de feminización según quintil de ingreso de la ocupación principal",
       subtitle = "Ocupados con ingresos. Total aglomerados EPH. 1er trimestre de 2025.",
       x = "Quintil de ingreso", y = "% de mujeres") +
  theme_minimal()


## -----------------------------------------------------------------------------------------
ocupados_con_ingreso <- individual_25_t1 %>%
  mutate(PONDIIO = as.numeric(PONDIIO)) %>%
  filter(ESTADO == 1, P21 > 0) %>%
  mutate(Sexo = case_when(CH04 == 1 ~ "Varón",
                          CH04 == 2 ~ "Mujer"))

lorenz <- ocupados_con_ingreso %>%
  group_by(Sexo) %>%
  arrange(P21, .by_group = TRUE) %>%
  mutate(p = cumsum(PONDIIO) / sum(PONDIIO),
         L = cumsum(P21 * PONDIIO) / sum(P21 * PONDIIO)) %>%
  ungroup() %>%
  select(Sexo, p, L)

ggplot(lorenz, aes(x = p, y = L, color = Sexo)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey50") +
  geom_line(linewidth = 1) +
  scale_x_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(title = "Curva de Lorenz del ingreso de la ocupación principal, según sexo",
       subtitle = "Ocupados con ingresos. Total aglomerados EPH. 1er trimestre de 2025.",
       x = "% acumulado de ocupados", y = "% acumulado del ingreso",
       color = NULL) +
  coord_equal() +
  theme_minimal()


## -----------------------------------------------------------------------------------------
gini_por_sexo <- ocupados_con_ingreso %>%
  group_by(Sexo) %>%
  summarise(casos          = n(),
            poblacion      = sum(PONDIIO),
            ingreso_medio  = weighted.mean(P21, PONDIIO),
            gini           = reldist::gini(P21, PONDIIO),
            .groups = "drop")

gini_por_sexo


## -----------------------------------------------------------------------------------------
ocupados_edad <- ocupados_con_ingreso %>%
  filter(P21 >0,
         T_VI >=0,
         CH06 %in% c(14:65),
         PP3E_TOT >0 & PP3E_TOT != 999,
         )  


## ----warning=FALSE,message=F--------------------------------------------------------------
ocup_edad_sexo<- ocupados_edad %>% 
  select(Sexo,P21,CH06,PP3E_TOT)

GGally::ggpairs(ocup_edad_sexo,
        ggplot2::aes(
          color = Sexo,
          fill = Sexo,
          alpha = 0.8
        ),
        labeller = label_wrap_gen(width = 5)) +
  theme_minimal() +
  scale_color_manual(values = c("#45818e", "#CA225E")) +
  scale_fill_manual(values = c("#45818e", "#CA225E")) +
  theme(strip.text.x = element_text(size = 10),
        strip.text.y = element_text(size = 10))


## -----------------------------------------------------------------------------------------
corr <- ocupados_edad %>% 
  select(P21,CH06,PP3E_TOT,T_VI) %>% 
  # Calculamos la matriz de correlaciones
  cor()

corr


## -----------------------------------------------------------------------------------------
library(corrplot)


## -----------------------------------------------------------------------------------------
#Graficamos con nuestro propio espectro de colores
corr %>% 
  corrplot(tl.col = "black", method = "square")


## -----------------------------------------------------------------------------------------
test_horas <- cor.test(ocupados_edad$P21, ocupados_edad$PP3E_TOT,
                       method = "pearson")

test_horas

