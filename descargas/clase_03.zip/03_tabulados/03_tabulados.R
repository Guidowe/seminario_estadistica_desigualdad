## ------------------------------------------------------------------
#| label: setup
#| message: false
#| warning: false

library(tidyverse)
library(eph)
library(openxlsx)


## ------------------------------------------------------------------
individual_25_t1 <- read.table("bases_eph/usu_individual_T125.txt",
                               sep = ";", dec = ",", header = TRUE, fill = TRUE)


## ------------------------------------------------------------------
asalariados <- individual_25_t1 %>%
  filter(ESTADO == 1, CAT_OCUP == 3) %>%     # ocupados asalariados
  filter(PP07H %in% c(1, 2)) %>%             # con respuesta válida sobre descuento jubilatorio
  filter(between(CH06, 14, 60)) %>%          # acotamos el universo a edades activas
  mutate(
    registro = factor(
      case_when(PP07H == 1 ~ "Registrado",
                PP07H == 2 ~ "No registrado"),
      levels = c("Registrado", "No registrado")),

    grupo_edad = factor(
      case_when(CH06 <= 35 ~ "14 a 35",
                CH06 >  35 ~ "36 a 60"),
      levels = c("14 a 35", "36 a 60")),

    nivel_ed = factor(
      case_when(NIVEL_ED %in% c(7, 1, 2, 3) ~ "Hasta secundaria inc.",
                NIVEL_ED %in% c(4, 5)       ~ "Secundaria completa",
                NIVEL_ED == 6               ~ "Superior completo",
                TRUE                        ~ "Ns/Nr"),
      levels = c("Hasta secundaria inc.", "Secundaria completa",
                 "Superior completo", "Ns/Nr")),

    estado_civil = factor(
      case_when(CH07 %in% 1:4 ~ "Resto",     
                CH07 == 5     ~ "Soltero/a",
                TRUE          ~ "Ns/Nr"),
      levels = c("Resto", "Soltero/a", "Ns/Nr")))

# ¿Con cuántos casos nos quedamos?
asalariados %>%
  summarise(casos_muestrales = n(),
            poblacion_expandida = sum(PONDERA))


## ------------------------------------------------------------------
calculate_tabulates(base = asalariados,
                    x = "registro",
                    y = "grupo_edad",
                    weights = "PONDERA",
                    add.totals = "both")


## ------------------------------------------------------------------
calculate_tabulates(base = asalariados,
                    x = "registro",
                    y = "grupo_edad",
                    weights = "PONDERA",
                    add.percentage = "col")


## ------------------------------------------------------------------
tasa_no_reg_edades <- asalariados %>%
  group_by(grupo_edad) %>%
  summarise(tasa_no_registro = weighted.mean(registro == "No registrado", PONDERA) * 100,
            .groups = "drop")

tasa_no_reg_edades


## ------------------------------------------------------------------
tabla_edad <- table(asalariados$grupo_edad, asalariados$registro)
tabla_edad

test_edad <- chisq.test(tabla_edad, correct = FALSE)
test_edad


## ------------------------------------------------------------------
n_casos <- sum(tabla_edad)
chi2     <- unname(test_edad$statistic)

phi      <- sqrt(chi2 / n_casos)
v_cramer <- sqrt(chi2 / (n_casos * (min(dim(tabla_edad)) - 1)))

tibble(chi2 = chi2, n = n_casos, phi = phi, v_cramer = v_cramer)


## ------------------------------------------------------------------
coef_asociacion <- function(datos, x, y) {

  tabla <- table(datos[[x]], datos[[y]])
  test  <- chisq.test(tabla, correct = FALSE)
  n     <- sum(tabla)

  tibble(
    n        = n,
    chi2     = round(unname(test$statistic), 1),
    gl       = unname(test$parameter),
    p_valor  = signif(test$p.value, 3),
    v_cramer = round(sqrt(unname(test$statistic) / (n * (min(dim(tabla)) - 1))), 3))
}

# La probamos: tiene que devolver lo mismo que calculamos a mano
coef_asociacion(asalariados, "grupo_edad", "registro")


## ------------------------------------------------------------------
base_ed <- asalariados %>%
  filter(nivel_ed != "Ns/Nr") %>%
  droplevels()

coef_por_educ <- base_ed %>%
  group_by(nivel_ed) %>%
  group_modify(~ coef_asociacion(.x, "grupo_edad", "registro")) %>%
  ungroup()

brecha_por_educ <- base_ed %>%
  group_by(nivel_ed, grupo_edad) %>%
  summarise(tasa_no_registro = weighted.mean(registro == "No registrado", PONDERA) * 100,
            .groups = "drop") %>%
  pivot_wider(names_from = grupo_edad, values_from = tasa_no_registro) %>%
  rename(jovenes = `14 a 35`, adultos = `36 a 60`) %>%
  mutate(brecha_pp = round(jovenes - adultos, 1),
         razon     = round(jovenes / adultos, 2))

resumen_educ <- brecha_por_educ %>%
  left_join(coef_por_educ, by = "nivel_ed")

resumen_educ


## ------------------------------------------------------------------
base_ec <- asalariados %>%
  filter(estado_civil != "Ns/Nr") %>%
  droplevels()

calculate_tabulates(base = base_ec,
                    x = "registro",
                    y = "estado_civil",
                    weights = "PONDERA",
                    add.percentage = "col")


## ------------------------------------------------------------------
brecha_ec <- base_ec %>%
  group_by(estado_civil) %>%
  summarise(tasa_no_registro = weighted.mean(registro == "No registrado", PONDERA) * 100,
            .groups = "drop") %>%
  pivot_wider(names_from = estado_civil, values_from = tasa_no_registro) %>%
  rename(solteros = `Soltero/a`, resto = Resto) %>%
  mutate(brecha_pp = round(solteros - resto, 1))

brecha_ec
coef_asociacion(base_ec, "estado_civil", "registro")


## ------------------------------------------------------------------
coef_por_edad <- base_ec %>%
  group_by(grupo_edad) %>%
  group_modify(~ coef_asociacion(.x, "estado_civil", "registro")) %>%
  ungroup()

brecha_por_edad <- base_ec %>%
  group_by(grupo_edad, estado_civil) %>%
  summarise(tasa_no_registro = weighted.mean(registro == "No registrado", PONDERA) * 100,
            pob = sum(PONDERA),
            .groups = "drop") %>%
  group_by(grupo_edad) %>%
  mutate(peso = sum(pob)) %>%        # población de cada grupo etario (la usamos en el paso 3)
  ungroup() %>%
  select(-pob) %>%
  pivot_wider(names_from = estado_civil, values_from = tasa_no_registro) %>%
  rename(solteros = `Soltero/a`, resto = Resto) %>%
  mutate(brecha_pp = round(solteros - resto, 1))

brecha_por_edad %>%
  left_join(coef_por_edad, by = "grupo_edad")


## ------------------------------------------------------------------
brecha_por_edad %>%
  summarise(brecha_original         = brecha_ec$brecha_pp,
            brecha_parcial_promedio = round(weighted.mean(brecha_pp, peso), 1),
            reduccion_pct           = round((1 - brecha_parcial_promedio / brecha_original) * 100))


## ------------------------------------------------------------------
base_fina <- base_ec %>%
  mutate(edad_fina = cut(CH06,
                         breaks = c(13, 24, 34, 44, 54, 60),
                         labels = c("14 a 24", "25 a 34", "35 a 44",
                                    "45 a 54", "55 a 60")))

control_fino <- base_fina %>%
  group_by(edad_fina, estado_civil) %>%
  summarise(tasa_no_registro = weighted.mean(registro == "No registrado", PONDERA) * 100,
            pob = sum(PONDERA),
            .groups = "drop") %>%
  group_by(edad_fina) %>%
  mutate(peso = sum(pob)) %>%
  ungroup() %>%
  select(-pob) %>%
  pivot_wider(names_from = estado_civil, values_from = tasa_no_registro) %>%
  rename(solteros = `Soltero/a`, resto = Resto) %>%
  mutate(brecha_pp = round(solteros - resto, 1)) %>%
  left_join(base_fina %>%
              group_by(edad_fina) %>%
              group_modify(~ coef_asociacion(.x, "estado_civil", "registro")) %>%
              ungroup(),
            by = "edad_fina")

control_fino

control_fino %>%
  summarise(brecha_parcial_promedio = round(weighted.mean(brecha_pp, peso), 1))


## ------------------------------------------------------------------
# X <-> T : ¿la composición etaria difiere según estado civil?
calculate_tabulates(base = base_ec,
                    x = "grupo_edad", y = "estado_civil",
                    weights = "PONDERA", add.percentage = "col")

coef_asociacion(base_ec, "estado_civil", "grupo_edad")

# T <-> Y : ya lo sabemos, es la relación con la que abrimos la clase
coef_asociacion(base_ec, "grupo_edad", "registro")


## ------------------------------------------------------------------
#| eval: false

# write.xlsx(
#   list("tasa_no_reg_edades"      = tasa_no_reg_edades,
#        "interaccion_educ"  = resumen_educ,
#        "control_edad"      = brecha_por_edad %>% left_join(coef_por_edad, by = "grupo_edad"),
#        "control_edad_fino" = control_fino),
#   file = "Resultados/clase03_asociacion.xlsx")

