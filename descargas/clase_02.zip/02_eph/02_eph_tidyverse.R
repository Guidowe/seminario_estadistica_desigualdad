# ===========================================================================
# SEMINARIO: Estadistica y programacion para estudios del trabajo,
#            desigualdad y pobreza -- Doctorado en Ciencias Sociales (UBA)
#
# Este es el codigo de la clase, sin el texto explicativo.
# La explicacion completa esta en el archivo .html que acompania a este
# script: abrilo en el navegador y tenelo al lado mientras trabajas.
#
# ANTES DE CORRER NADA:
#   Abri el proyecto haciendo doble clic en 'seminario.Rproj'.
#   Si abriste este archivo suelto, R no va a encontrar las bases de datos.
#
# COMO SE EJECUTA:
#   Para el cursor en una linea y apreta Ctrl + Enter (Cmd + Enter en Mac).
#   Se corre esa linea y el cursor baja a la siguiente. De a una, sin apuro.
#
# NO EDITES ESTE ARCHIVO PENSANDO QUE SE GUARDA:
#   se regenera automaticamente a partir de la fuente. Si queres tomar
#   notas, guardalo con otro nombre (por ejemplo 'mis_notas_clase1.R').
# ===========================================================================

# [generado automaticamente desde 02_eph_ponderadores.qmd el 04/09/2026]

## ----warning=FALSE,message=FALSE--------------------------------------------
library(tidyverse)
library(openxlsx)
library(eph)
library(scales)


## ---------------------------------------------------------------------------
list.files("bases_eph/")


## ---------------------------------------------------------------------------
individual_25_t1 <-
  read.table("bases_eph/usu_individual_T125.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )
  
  
Aglom <- openxlsx::read.xlsx("bases_eph/Aglomerados y Regiones EPH.xlsx")


## ---------------------------------------------------------------------------
Datos  <- individual_25_t1[
  c("AGLOMERADO","MAS_500",
    "CH04","CH06","NIVEL_ED",
    "P47T","PONDERA","PONDII")]



## ---------------------------------------------------------------------------
frecuencias_mas500<- table(
  individual_25_t1$MAS_500,useNA = "always")

frecuencias_mas500


## ---------------------------------------------------------------------------
prop.table(frecuencias_mas500)


## ---------------------------------------------------------------------------
table(Datos$NIVEL_ED)


## ---------------------------------------------------------------------------
Datos$NIVEL_ED[Datos$NIVEL_ED==7] <- 1
table(Datos$NIVEL_ED)


## ---------------------------------------------------------------------------
Datos_etiquetados <- eph::organize_labels(Datos)
table(Datos_etiquetados$NIVEL_ED,useNA = "always")



## ---------------------------------------------------------------------------
hist(Datos$NIVEL_ED)


## ---------------------------------------------------------------------------
table(Datos$MAS_500,Datos$CH04) 


## ---------------------------------------------------------------------------
eph::calculate_tabulates(base = Datos,x = "MAS_500",y = "CH04",weights = "PONDERA",add.totals = "both")


## ---------------------------------------------------------------------------
summary(Datos) 


## ---------------------------------------------------------------------------
Datos$CH06[Datos$CH06==-1] <- 0

edad_prom<- mean(Datos$CH06)


## ---------------------------------------------------------------------------
edad_prom_pond <- weighted.mean(Datos$CH06,Datos$PONDERA)
edad_prom_pond


## ---------------------------------------------------------------------------
median(Datos$CH06)


## ---------------------------------------------------------------------------
get_mode <- function(x) {
  uniq_x <- unique(x)
  uniq_x[which.max(tabulate(match(x, uniq_x)))]
}

get_mode(Datos$CH06)
sd(Datos$CH06)
cv


## ---------------------------------------------------------------------------
desvio_muestral <- sd(Datos$CH06)



## ---------------------------------------------------------------------------
library(matrixStats)
desvio_pond <- weightedSd(Datos$CH06,Datos$PONDERA)


## ---------------------------------------------------------------------------
cv <- desvio_pond/edad_prom_pond
cv


## ---------------------------------------------------------------------------
unique(Datos$AGLOMERADO)


## ---------------------------------------------------------------------------
sample_n(tbl = Datos,size = 9)


## ---------------------------------------------------------------------------
pepito <- Datos %>% 
  filter(CH04==1 , CH06>=50)



## ---------------------------------------------------------------------------
Datos %>% 
    filter(CH04==1| CH06>=50) %>% 
    head(10) # Comando para que muestre los primeros 10 datos



## ---------------------------------------------------------------------------
Datos %>% 
  slice_max(order_by = P47T,n = 10)


## ---------------------------------------------------------------------------
Datos <- Datos %>% 
  rename(EDAD = CH06)

head(Datos)


## ---------------------------------------------------------------------------
Datos <- Datos %>% 
  mutate(Edad_cuadrado=EDAD^2,
         Edad_cubo =EDAD^3) 

head(Datos)


## ---------------------------------------------------------------------------
Datos <- Datos %>% 
  mutate(Grupos_Etarios = case_when(EDAD  < 18   ~ "Menores",
                                 EDAD  %in%  18:65   ~ "Adultos",
                                 EDAD  > 65 ~ "Adultos Mayores"))
head(Datos)


## ---------------------------------------------------------------------------
#Conservo solo 2 variables
Datos %>% 
  select(CH04,PONDERA) %>% 
  head()

#Conservo todas las variables desde la 3era
Datos %>% 
  select(3:ncol(.))%>% 
  head()


## ---------------------------------------------------------------------------
Datos <- Datos %>% 
  arrange(CH04,EDAD)

Datos %>% 
  head()


## ---------------------------------------------------------------------------
#Recuerden que los menores de un año están clasificados con el valor -1
Datos <- Datos %>% 
  mutate(edad.corregida=ifelse(EDAD == -1,yes = 0,no = EDAD))

#R BASE#
mean(Datos$edad.corregida,na.rm = T) #sin ponderar
weighted.mean(Datos$edad.corregida,Datos$PONDERA) #ponderado

#Tidyverse

Datos %>%      
 summarise(Edad_prom = mean(edad.corregida),  #sin ponderar
           Edad_prom_pond = weighted.mean(x = edad.corregida,w = PONDERA)) #ponderado



## ---------------------------------------------------------------------------
Datos %>% 
  group_by(CH04) %>%
  summarise(Edad_Prom = weighted.mean(EDAD,PONDERA))


## ---------------------------------------------------------------------------
Encadenado <- Datos %>% 
  filter(Grupos_Etarios == "Adultos") %>% 
  mutate(Sexo = case_when(CH04 == 1 ~ "Varon",
                          CH04 == 2 ~ "Mujer")) %>% 
  select(-Edad_cuadrado)
  
head(Encadenado)


## ----echo=TRUE--------------------------------------------------------------
Aglom

Datos_join <- Datos %>% 
  left_join(.,Aglom, by = "AGLOMERADO")

 
head(Datos_join)





## ---------------------------------------------------------------------------
Poblacion_Aglomerados <- Datos_join %>% 
  group_by(Nom_Aglo) %>% 
  summarise(Menores = sum(PONDERA[Grupos_Etarios=="Menores"]),
            Adultos = sum(PONDERA[Grupos_Etarios=="Adultos"]),
            Adultos_Mayores = sum(PONDERA[Grupos_Etarios=="Adultos Mayores"]))

Poblacion_Aglomerados


## ---------------------------------------------------------------------------
pob.aglo.long <- Poblacion_Aglomerados %>% 
  pivot_longer(cols = 2:4,names_to = "Grupo_Etario",values_to = "Poblacion")

pob.aglo.long


## ---------------------------------------------------------------------------
pob.aglo.long %>% 
  pivot_wider(names_from = "Grupo_Etario",values_from = "Poblacion")
  


## ----echo=TRUE--------------------------------------------------------------
Poblacion_ocupados <- individual_25_t1 %>% 
  summarise(Poblacion         = sum(PONDERA),
            Ocupados          = sum(PONDERA[ESTADO == 1]))

Poblacion_ocupados


## ----echo=TRUE--------------------------------------------------------------
Empleo <- individual_25_t1 %>% 
  summarise(Poblacion         = sum(PONDERA),
            Ocupados          = sum(PONDERA[ESTADO == 1]),
            Tasa_Empleo    = Ocupados/Poblacion)

Empleo


## ---------------------------------------------------------------------------
Empleo %>% 
  mutate(Tasa_Empleo_Porc = scales::percent(Tasa_Empleo))


## ---------------------------------------------------------------------------
Empleo_aglo <- individual_25_t1 %>% 
  group_by(AGLOMERADO)%>%
  summarise(Poblacion         = sum(PONDERA),
            Ocupados          = sum(PONDERA[ESTADO == 1]),
            Tasa_Empleo    = Ocupados/Poblacion)



## ----eval=FALSE-------------------------------------------------------------
# dir.create("Resultados")
# openxlsx::write.xlsx(x = Empleo,file =  "Resultados/miexportacion.xlsx")


## ----eval=FALSE-------------------------------------------------------------
# dir.create("Resultados")
# openxlsx::write.xlsx(
#   x = list(Empleo,Empleo_aglo),
#   file =  "Resultados/miexportacion_2.xlsx")

