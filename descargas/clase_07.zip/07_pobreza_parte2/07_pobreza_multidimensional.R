## -----------------------------------------------------------------------------
library(tidyverse)
library(openxlsx)


## -----------------------------------------------------------------------------
archivos_hogar <- c("bases_eph/usu_hogar_T125.txt",
                    "bases_eph/usu_hogar_T225.txt",
                    "bases_eph/usu_hogar_T325.txt",
                    "bases_eph/usu_hogar_T425.txt")

archivos_individual <- c("bases_eph/usu_individual_T125.txt",
                         "bases_eph/usu_individual_T225.txt",
                         "bases_eph/usu_individual_T325.txt",
                         "bases_eph/usu_individual_T425.txt")

var_hogar <- c("CODUSU", "NRO_HOGAR", "ANO4", "TRIMESTRE", "REGION", "PONDERA",
               "IV1", "IV3", "IV4", "IV8", "II1", "IX_TOT")

var_individual <- c("CODUSU", "NRO_HOGAR", "COMPONENTE", "ANO4", "TRIMESTRE",
                    "REGION", "PONDERA", "PONDIH", "CH03", "CH04", "CH06",
                    "CH10", "NIVEL_ED", "ESTADO", "ITF")

hogares <- read_delim(archivos_hogar,
                      delim = ";",
                      locale = locale(decimal_mark = ","),
                      col_select = all_of(var_hogar),
                      show_col_types = FALSE)

individuos <- read_delim(archivos_individual,
                         delim = ";",
                         locale = locale(decimal_mark = ","),
                         col_select = all_of(var_individual),
                         show_col_types = FALSE)

hogares |> count(ANO4, TRIMESTRE)
individuos |> count(ANO4, TRIMESTRE)


## -----------------------------------------------------------------------------
id_hogar <- c("ANO4", "TRIMESTRE", "CODUSU", "NRO_HOGAR")


## -----------------------------------------------------------------------------
hogares_nbi <- hogares |>
  mutate(
    nbi_1 = case_when(!IV1 %in% c(1, 2)   ~ 1,
                      IV4 == 7 | IV3 == 3 ~ 1,
                      .default = 0),
    nbi_2 = case_when(IV8 == 1 ~ 0,
                      .default = 1),
    cuartos = if_else(II1 == 0, 1, II1),
    personas_por_cuarto = IX_TOT / cuartos,
    nbi_3 = case_when(personas_por_cuarto >= 3 ~ 1,
                      .default = 0)
  )

hogares_nbi |> count(nbi_1)
hogares_nbi |> count(nbi_2)
hogares_nbi |> count(nbi_3)


## -----------------------------------------------------------------------------
individuos_nbi <- individuos |>
  mutate(
    nn_612_noasiste = case_when(CH06 >= 6 & CH06 <= 12 & CH10 != 1 ~ 1,
                                .default = 0),
    ocupado = case_when(ESTADO == 1 ~ 1,
                        .default = 0),
    jefe_beduc = case_when(CH03 == 1 & NIVEL_ED == 1 ~ 1,
                           .default = 0)
  )


## -----------------------------------------------------------------------------
hogares_desde_personas <- individuos_nbi |>
  group_by(ANO4, TRIMESTRE, CODUSU, NRO_HOGAR) |>
  summarise(numcomp       = n(),
            numocup       = sum(ocupado),
            h_jef_beduc   = max(jefe_beduc),
            h_nn_noasiste = max(nn_612_noasiste),
            .groups = "drop")

hogares_desde_personas


## -----------------------------------------------------------------------------
hogares_desde_personas <- hogares_desde_personas |>
  mutate(
    nbi_4 = h_nn_noasiste,
    nbi_5 = case_when(numocup > 0 & numcomp / numocup >= 4 & h_jef_beduc == 1 ~ 1,
                      .default = 0)
  )


## -----------------------------------------------------------------------------
hogares_nbi <- hogares_nbi |>
  left_join(hogares_desde_personas, by = id_hogar) |>
  mutate(cant_nbi  = nbi_1 + nbi_2 + nbi_3 + nbi_4 + nbi_5,
         h_nbi_con5 = if_else(cant_nbi >= 1, 1, 0))


## -----------------------------------------------------------------------------
hogares_nbi <- hogares_nbi |>
  mutate(h_nbi = if_else(nbi_1 + nbi_2 + nbi_3 + nbi_4 >= 1, 1, 0))

hogares_nbi |>
  select(all_of(id_hogar), nbi_1:nbi_3, nbi_4, nbi_5, cant_nbi, h_nbi_con5, h_nbi) |>
  head(10)


## -----------------------------------------------------------------------------
hogares_nbi <- hogares_nbi |>
  mutate(Semestre = case_when(TRIMESTRE %in% 1:2 ~ 1,
                              TRIMESTRE %in% 3:4 ~ 2),
         Anio.Semestre = paste(ANO4, Semestre, sep = "."))


## -----------------------------------------------------------------------------
hogares_nbi |>
  group_by(Anio.Semestre) |>
  summarise(hogares_nbi_con5 = weighted.mean(h_nbi_con5, PONDERA),
            hogares_nbi      = weighted.mean(h_nbi, PONDERA))


## -----------------------------------------------------------------------------
nbi_por_indicador <- hogares_nbi |>
  pivot_longer(cols = c(nbi_1, nbi_2, nbi_3, nbi_4, nbi_5, h_nbi),
               names_to = "indicador",
               values_to = "valor") |>
  group_by(Anio.Semestre, indicador) |>
  summarise(prop_hogares = weighted.mean(valor, PONDERA), .groups = "drop") |>
  pivot_wider(names_from = Anio.Semestre, values_from = prop_hogares)

nbi_por_indicador


## -----------------------------------------------------------------------------
hogares_nbi |>
  mutate(cant_nbi_1a4 = nbi_1 + nbi_2 + nbi_3 + nbi_4) |>
  group_by(Anio.Semestre, cant_nbi_1a4) |>
  summarise(hogares = sum(PONDERA), .groups = "drop_last") |>
  mutate(prop = hogares / sum(hogares))


## -----------------------------------------------------------------------------
personas_nbi <- individuos |>
  left_join(hogares_nbi |> select(all_of(id_hogar), Anio.Semestre,
                                  nbi_1:nbi_3, nbi_4, nbi_5, h_nbi),
            by = id_hogar)

personas_nbi |>
  group_by(Anio.Semestre) |>
  summarise(personas_nbi = weighted.mean(h_nbi, PONDERA))


## -----------------------------------------------------------------------------
adequi <- read.xlsx("bases_eph/ADEQUI.xlsx")
CBA    <- read.xlsx("bases_eph/canastas_eph.xlsx", sheet = "CBA")
CBT    <- read.xlsx("bases_eph/canastas_eph.xlsx", sheet = "CBT")
dic.regiones <- read.xlsx("bases_eph/Aglomerados y Regiones EPH.xlsx",
                          sheet = "Regiones EPH",
                          startRow = 2)

Canastas_Reg <- bind_rows(CBA |> mutate(Canasta = "CBA"),
                          CBT |> mutate(Canasta = "CBT")) |>
  pivot_longer(cols = 3:8, names_to = "Region", values_to = "Valor") |>
  mutate(Trimestre = case_when(Mes %in% 1:3   ~ 1,
                               Mes %in% 4:6   ~ 2,
                               Mes %in% 7:9   ~ 3,
                               Mes %in% 10:12 ~ 4),
         Periodo = paste(Anio, Trimestre, sep = ".")) |>
  group_by(Canasta, Region, Periodo) |>
  summarise(Valor = mean(Valor), .groups = "drop") |>
  pivot_wider(names_from = Canasta, values_from = Valor) |>
  left_join(dic.regiones, by = "Region")

personas_nbi_pobreza <- personas_nbi |>
  mutate(Periodo = paste(ANO4, TRIMESTRE, sep = ".")) |>
  left_join(adequi, by = c("CH04", "CH06")) |>
  left_join(Canastas_Reg, by = c("REGION", "Periodo")) |>
  group_by(CODUSU, NRO_HOGAR, Periodo) |>
  mutate(Adequi_hogar = sum(adequi)) |>
  ungroup() |>
  mutate(CBA_hogar = CBA * Adequi_hogar,
         CBT_hogar = CBT * Adequi_hogar,
         Situacion = case_when(ITF <  CBA_hogar ~ "Indigente",
                               ITF <  CBT_hogar ~ "Pobre",
                               ITF >= CBT_hogar ~ "No.Pobre"),
         h_pobreza = if_else(Situacion %in% c("Pobre", "Indigente"), 1, 0))

personas_nbi_pobreza |>
  group_by(Anio.Semestre) |>
  summarise(tasa_pobreza = weighted.mean(h_pobreza, PONDIH))


## -----------------------------------------------------------------------------
matriz <- personas_nbi_pobreza |>
  group_by(Anio.Semestre, h_pobreza, h_nbi) |>
  summarise(personas = sum(PONDIH), .groups = "drop") |>
  group_by(Anio.Semestre) |>
  mutate(prop = personas / sum(personas)) |>
  ungroup()

matriz |>
  select(-personas) |>
  pivot_wider(names_from = h_nbi, values_from = prop, names_prefix = "nbi_")


## -----------------------------------------------------------------------------
personas_combinado <- personas_nbi_pobreza |>
  mutate(
    h_pob_combinada = case_when(h_nbi == 1                   ~ "1. Pobres estructurales",
                                h_nbi == 0 & h_pobreza == 1  ~ "2. Pobres recientes",
                                h_nbi == 0 & h_pobreza == 0  ~ "3. No pobres"),
    h_pob_combinadaB = case_when(h_nbi == 1 & h_pobreza == 1 ~ "1. Pobres estructurales",
                                 h_nbi == 1 | h_pobreza == 1 ~ "2. Pobres no estructurales",
                                 .default                    =  "3. No pobres")
  )


## -----------------------------------------------------------------------------
personas_combinado |>
  group_by(Anio.Semestre, h_pob_combinada) |>
  summarise(personas = sum(PONDIH), .groups = "drop_last") |>
  mutate(prop = personas / sum(personas)) |>
  select(-personas) |>
  pivot_wider(names_from = Anio.Semestre, values_from = prop)

personas_combinado |>
  group_by(Anio.Semestre, h_pob_combinadaB) |>
  summarise(personas = sum(PONDIH), .groups = "drop_last") |>
  mutate(prop = personas / sum(personas)) |>
  select(-personas) |>
  pivot_wider(names_from = Anio.Semestre, values_from = prop)


## -----------------------------------------------------------------------------
personas_combinado |>
  filter(h_pobreza == 1) |>
  group_by(Anio.Semestre) |>
  summarise(prop_con_nbi = weighted.mean(h_nbi, PONDIH))

