## ----warning = FALSE----------------------------------------------------------------------
library(tidyverse, warn = FALSE)
library(openxlsx, warn = FALSE)


## ----warning=FALSE------------------------------------------------------------------------
var_interes <- c('CODUSU','NRO_HOGAR' ,'COMPONENTE','ANO4','TRIMESTRE','REGION',"P47T",
             'AGLOMERADO', 'PONDERA', 'CH04', 'CH06', 'ITF', 'PONDIH','P21')

individual_25_t1 <-
  read.table("bases_eph/usu_individual_T125.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )

individual_25_t2 <-
  read.table("bases_eph/usu_individual_T225.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )

individual_25_t3 <-
  read.table("bases_eph/usu_individual_T325.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )

individual_25_t4 <-
  read.table("bases_eph/usu_individual_T425.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )
bases_25 <- bind_rows(
  individual_25_t1 %>% select(all_of(var_interes)),
  individual_25_t2 %>% select(all_of(var_interes)),
  individual_25_t3 %>% select(all_of(var_interes)),
  individual_25_t4 %>% select(all_of(var_interes)),
  )


## -----------------------------------------------------------------------------------------

adequi <- read.xlsx("bases_eph/ADEQUI.xlsx")
CBA    <- read.xlsx("bases_eph/canastas_eph.xlsx",sheet = "CBA")
CBT    <- read.xlsx("bases_eph/canastas_eph.xlsx",sheet = "CBT")
dic.regiones <- read.xlsx("bases_eph/Aglomerados y Regiones EPH.xlsx",
                          sheet = "Regiones EPH", 
                          startRow = 2)




## -----------------------------------------------------------------------------------------
CBA <- CBA %>% 
  mutate(Canasta = 'CBA')

CBT <- CBT %>% 
  mutate(Canasta = 'CBT')

Canastas_Reg <- bind_rows(CBA,CBT)                       %>% 
  pivot_longer(cols = 3:8,names_to = "Region", values_to = "Valor")             %>%
  mutate(Trimestre = case_when(Mes %in% c(1:3)   ~1,
                               Mes %in% c(4:6)   ~2,
                               Mes %in% c(7:9)   ~3,
                               Mes %in% c(10:12) ~4),
         Periodo = paste(Anio, Trimestre, sep='.'))      


## -----------------------------------------------------------------------------------------
Canastas_Reg_2 <- Canastas_Reg %>% 
  group_by(Canasta, Region, Periodo)                     %>% 
  summarise(Valor = mean(Valor))                         %>% 
  spread(., Canasta,Valor)                               %>% 
  left_join(., dic.regiones, by = "Region")              %>% 
  ungroup()                                              
Canastas_Reg_2


## ----warning=FALSE------------------------------------------------------------------------
Pobreza_Individual <- bases_25 %>% 
  mutate(Periodo = paste(ANO4, TRIMESTRE, sep='.')) %>% 
  left_join(., adequi, by = c("CH04", "CH06")) %>% 
  left_join(., Canastas_Reg_2, by = c("REGION", "Periodo"))    


Pobreza_Individual[1:10,1:10]


## ----warning=FALSE------------------------------------------------------------------------
Pobreza_Individual_paso2 <- Pobreza_Individual %>%  
  group_by(CODUSU, NRO_HOGAR, Periodo)                          %>% 
  mutate(Adequi_hogar = sum(adequi))                            %>%
  ungroup()                                                      
Pobreza_Individual_paso2[1:10,1:10]


## ----warning=FALSE------------------------------------------------------------------------
Pobreza_Individual_paso3 <-  Pobreza_Individual_paso2 %>% 
 mutate(CBA = CBA*Adequi_hogar,
        CBT = CBT*Adequi_hogar,
        Situacion = case_when(ITF<CBA            ~ 'Indigente',
                               ITF>=CBA & ITF<CBT ~ 'Pobre',
                               ITF>=CBT           ~ 'No.Pobre'))  

Pobreza_Individual_paso3[1:10,1:10]


## -----------------------------------------------------------------------------------------
Pobreza_resumen <- Pobreza_Individual_paso3 %>% 
  group_by(Periodo) %>% 
  summarise(indigentes = sum(PONDIH[Situacion == 'Indigente'],
                             na.rm = TRUE),
            pobres     = sum(PONDIH[Situacion %in% c('Pobre', 'Indigente')],
                         na.rm = TRUE),
            poblacion  = sum(PONDIH,na.rm = T),
            Tasa_indigencia = indigentes/poblacion,
            Tasa_pobreza = pobres/poblacion)

Pobreza_resumen


## -----------------------------------------------------------------------------------------
Pobreza_resumen_region <- Pobreza_Individual_paso3 %>% 
  group_by(Periodo,Region) %>% 
  summarise(indigentes = sum(PONDIH[Situacion == 'Indigente'],
                             na.rm = TRUE),
            pobres     = sum(PONDIH[Situacion %in% c('Pobre', 'Indigente')],
                         na.rm = TRUE),
            poblacion  = sum(PONDIH,na.rm = T),
            Tasa_indigencia = indigentes/poblacion,
            Tasa_pobreza = pobres/poblacion)
Pobreza_resumen_region


## -----------------------------------------------------------------------------------------
Pobreza_Individual_semestres <- Pobreza_Individual_paso3 |> 
  mutate(Semestre = case_when(TRIMESTRE %in% 1:2 ~ 1,
                              TRIMESTRE %in% 3:4 ~ 2),
         Anio.Semestre = paste(ANO4,Semestre,sep = "."))

Pobreza_Individual_semestres %>% 
  group_by(Anio.Semestre) %>% 
  summarise(indigentes = sum(PONDIH[Situacion == 'Indigente'],
                             na.rm = TRUE),
            pobres     = sum(PONDIH[Situacion %in% c('Pobre', 'Indigente')],
                         na.rm = TRUE),
            poblacion  = sum(PONDIH,na.rm = T),
            Tasa_indigencia = indigentes/poblacion,
            Tasa_pobreza = pobres/poblacion)


## -----------------------------------------------------------------------------------------
lineas_pobreza <- eph::get_poverty_lines(regional = T)
adulto_equivalente<- eph::adulto_equivalente

base_con_identificador <- eph::calculate_poverty(
  base = bases_25 |> filter(TRIMESTRE %in% 1:2),
  basket = lineas_pobreza,
  print_summary = T,
  window = "semester")

base_para_inspeccionar <- base_con_identificador %>% 
  select(CODUSU,NRO_HOGAR,COMPONENTE,ITF,adequi_hogar,CBT_hogar,CBA_hogar,region,situacion)

head(base_para_inspeccionar)

