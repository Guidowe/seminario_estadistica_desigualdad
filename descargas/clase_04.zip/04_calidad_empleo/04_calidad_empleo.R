## ----warning=FALSE,message=FALSE----------------------------------------------------------
library(tidyverse)
library(openxlsx)
library(eph)
library(questionr)


## -----------------------------------------------------------------------------------------
individual_25_t1 <-
  read.table("bases_eph/usu_individual_T125.txt",
  sep = ";",
  dec = ",",
  header = TRUE,
  fill = TRUE )


## -----------------------------------------------------------------------------------------
ocupados <- individual_25_t1 %>%
  filter(ESTADO == 1) %>%
  mutate(
    cat_ocup = factor(
      case_when(CAT_OCUP == 1 ~ "Patrón",
                CAT_OCUP == 2 ~ "Cuenta propia",
                CAT_OCUP == 3 ~ "Asalariado",
                CAT_OCUP == 4 ~ "Trab. familiar s/rem.",
                TRUE          ~ "Ns/Nr"),
      levels = c("Patrón","Cuenta propia","Asalariado","Trab. familiar s/rem.","Ns/Nr")),
     sector_legal =
      case_when(SECTOR == 1 ~ "Sector formal",
                SECTOR == 2 ~ "Sector informal",
                SECTOR == 3 ~ "Hogares",
                TRUE        ~ "Ns/Nr"),
    sexo = ifelse(CH04 %in% 1,"Varon","Mujer"),
    empleo_legal =
      case_when(EMPLEO == 1 ~ "Empleo formal",
                EMPLEO == 2 ~ "Empleo informal",
                TRUE        ~ "Ns/Nr"))


## -----------------------------------------------------------------------------------------
calculate_tabulates(base = ocupados,
                    x = "sector_legal",
                    y = "empleo_legal",
                    weights = "PONDERA",
                    add.totals = "both")


## -----------------------------------------------------------------------------------------
calculate_tabulates(base = ocupados,
                    x = "sector_legal",
                    y = "empleo_legal",
                    weights = "PONDERA",
                    add.percentage = "row")


## -----------------------------------------------------------------------------------------
empleo_con_deciles <- ocupados  %>% 
  filter(DECOCUR   %in% 1:10,EMPLEO %in% 1:2)%>% 
  mutate(low_paid = ifelse(DECOCUR %in% 1:3,"Si","No"),
         pondiio_recalibrado = PONDIIO/sum(PONDIIO)*n())

calculate_tabulates(base = empleo_con_deciles,
                    x = "low_paid",
                    y = "empleo_legal",
                    weights = "PONDIIO",
                    add.percentage = "col")


## -----------------------------------------------------------------------------------------
tabla_muestral <- table(empleo_con_deciles$low_paid, empleo_con_deciles$empleo_legal)
print("Tabla muestral sin recalibrar")
tabla_muestral

tabla_muestral_calibrada <- wtd.table(
  x = empleo_con_deciles$low_paid,
  y = empleo_con_deciles$empleo_legal,
  weights = empleo_con_deciles$pondiio_recalibrado)
print("Tabla muestral recalibrada")
tabla_muestral_calibrada

test_chi <- chisq.test(tabla_muestral_calibrada)
test_chi

n_casos <- sum(tabla_muestral_calibrada)
chi2     <- unname(test_chi$statistic)
vcramer     <- sqrt(chi2 / n_casos)
paste("V de Cramer: ",vcramer)



## -----------------------------------------------------------------------------------------
varones<- empleo_con_deciles |> filter(sexo == "Varon")
mujeres<- empleo_con_deciles |> filter(sexo == "Mujer")

calculate_tabulates(base = varones,
                    x = "low_paid",
                    y = "empleo_legal",
                    weights = "PONDIIO",
                    add.percentage = "col")

calculate_tabulates(base = mujeres,
                    x = "low_paid",
                    y = "empleo_legal",
                    weights = "PONDIIO",
                    add.percentage = "col")


## -----------------------------------------------------------------------------------------
varones_tabla<- wtd.table(
  x = varones$low_paid,
  y = varones$empleo_legal,
  weights = varones$pondiio_recalibrado)

varones_chi <- chisq.test(varones_tabla)
varones_n_casos <- sum(varones_tabla)
varones_chi2     <- unname(varones_chi$statistic)
varones_vcramer     <- sqrt(varones_chi2 / varones_n_casos)
print("Test Chi Varones:")
varones_chi
paste("V de Cramer Varones: ",varones_vcramer)



## -----------------------------------------------------------------------------------------
mujeres_tabla<- wtd.table(
  x = mujeres$low_paid,
  y = mujeres$empleo_legal,
  weights = mujeres$pondiio_recalibrado)

mujeres_chi <- chisq.test(mujeres_tabla)
mujeres_n_casos <- sum(mujeres_tabla)
mujeres_chi2     <- unname(mujeres_chi$statistic)
mujeres_vcramer     <- sqrt(mujeres_chi2 / mujeres_n_casos)
print("Test Chi Mujeres: ")
mujeres_chi
paste("V de Cramer Mujeres: ",mujeres_vcramer)


## -----------------------------------------------------------------------------------------
ocupados_cno <- ocupados %>%
  organize_cno()

# Miramos qué quedó
ocupados_cno %>%
  count(CALIFICACION, wt = PONDERA, sort = TRUE)


## -----------------------------------------------------------------------------------------
ocupados_siu <- ocupados_cno %>%
  mutate(
    # 1) Tamaño del establecimiento, con el corte de 5 ocupados
    tamanio_siu =
      case_when(PP04C %in% 1:5                    ~ "Hasta 5",
                PP04C %in% 6:12                   ~ "Más de 5",
                PP04C == 99 & PP04C99 == 1        ~ "Hasta 5",
                PP04C == 99 & PP04C99 %in% c(2,3) ~ "Más de 5",
                TRUE                              ~ "Ns/Nr"),

    # 2) ¿El puesto es profesional? (viene de organize_cno)
    profesional = if_else(CALIFICACION == "Profesionales", TRUE, FALSE, missing = FALSE),

    # 3) La clasificación PREALC propiamente dicha
    grupos_siu =
      case_when(
        PP04B1 == 1                                            ~ "Serv. Dom",      # servicio doméstico
        PP04A  == 1                                            ~ "S. Pub",   # sector público
        CAT_OCUP == 4                                          ~ "TFSR",      # familiar s/ remuneración
        CAT_OCUP == 2 & !profesional                           ~ "CP No Prof",      # cuenta propia no profesional
        CAT_OCUP == 2 &  profesional                           ~ "CP Prof",
        CAT_OCUP == 1 & tamanio_siu == "Hasta 5" & !profesional ~ "Patron Micro",     # patrón de microempresa
        CAT_OCUP == 1                                          ~ "Patron No Micro",
        CAT_OCUP == 3 & tamanio_siu == "Hasta 5"               ~ "Asal Micro",      # asalariado de microempresa
        CAT_OCUP == 3 & tamanio_siu == "Más de 5"              ~ "Asal No Micro",
        TRUE                                                   ~ "Ns/Nr"),
        # 4) La clasificación PREALC propiamente dicha
    siu_productivo = case_when(
      grupos_siu %in% c("Serv. Dom","TFSR",
                        "CP No Prof","Patron Micro",
                        "Asal Micro") ~ "Microinformal",
      grupos_siu == "S. Pub" ~ "Público",
      grupos_siu %in% c("Asal No Micro","Patron No Micro","CP Prof") ~ "Formal Privado",
        TRUE ~ "Ns/Nr")
    )


## -----------------------------------------------------------------------------------------
calculate_tabulates(base = ocupados_siu,
                    x = "siu_productivo",
                    weights = "PONDERA",
                    add.percentage = "col")



## -----------------------------------------------------------------------------------------
chequeo_resto <- ocupados_siu %>% 
  filter(siu_productivo == "Ns/Nr")

calculate_tabulates(chequeo_resto,
                    "tamanio_siu", 
                    "CAT_OCUP",
                    weights = "PONDERA")


## -----------------------------------------------------------------------------------------

siu_grupos<- calculate_tabulates(base = ocupados_siu,
                    x = "siu_productivo",
                    y = "grupos_siu",
                    add.percentage = "row",
                    weights = "PONDERA")
kableExtra::kable(siu_grupos)


## -----------------------------------------------------------------------------------------
siu_cat_ocup<- calculate_tabulates(base = ocupados_siu,
                    x = "siu_productivo",
                    y = "cat_ocup",
                    weights = "PONDERA",
                    add.percentage = "row")

kableExtra::kable(siu_cat_ocup)


## -----------------------------------------------------------------------------------------
calculate_tabulates(base = ocupados_siu,
                    x = "siu_productivo",
                    y = "sector_legal",
                    weights = "PONDERA",
                    add.totals = "both")


## -----------------------------------------------------------------------------------------
asalariados_2025_t1 <- ocupados_siu %>%
  filter(CAT_OCUP == 3) %>% # Ocupados asalariados
  mutate(
    descuento_jubil = case_when(PP07H == 1 ~ "Si",
                                PP07H == 2 ~ "No"),
    part.time.inv = case_when(PP3E_TOT < 35 & PP03G == 1 ~ "Si",
                             TRUE ~ "No"),
    tiempo.determinado = case_when(PP07C ==  1 ~ "Si",
                                   TRUE ~ "No"))



## -----------------------------------------------------------------------------------------
asalariados_2025_t1_deficits<- asalariados_2025_t1 %>% 
  mutate(
    
# 1 = el déficit está presente ; 0 = no lo está
    d_registro = if_else(
      descuento_jubil    == "No", 1, 0, missing = 0),
    d_part_time  = if_else(part.time.inv      == "Si", 1, 0, missing = 0),
    d_finalizacion = if_else(tiempo.determinado == "Si", 1, 0, missing = 0),
    cantidad_deficits = d_registro + d_part_time + d_finalizacion
    )
           


## -----------------------------------------------------------------------------------------
asalariados_2025_t1_deficits %>% 
  group_by(cantidad_deficits) %>% 
  summarise(Poblacion = sum(PONDERA))


## -----------------------------------------------------------------------------------------
indice_deficit <- asalariados_2025_t1_deficits %>%
  mutate(
    deficit = factor(
      case_when(cantidad_deficits == 0 ~ "Sin déficit",
                cantidad_deficits == 1 ~ "Déficit simple",
                cantidad_deficits == 2 ~ "Déficit moderado",
                cantidad_deficits == 3 ~ "Déficit severo"),
      levels = c("Sin déficit", "Déficit simple",
                 "Déficit moderado", "Déficit severo")))

# a) Distribución de la población asalariada según el índice
distribucion_deficit <- indice_deficit %>%
  group_by(deficit) %>%
  summarise(casos     = n(),
            poblacion = sum(PONDERA),
            .groups   = "drop") %>%
  mutate(porcentaje = round(poblacion / sum(poblacion) * 100, 1))

distribucion_deficit


## -----------------------------------------------------------------------------------------
calculate_tabulates(base = indice_deficit,                    x = "deficit",y = "sexo",
                    weights = "PONDERA",
                    add.percentage = "col")


## -----------------------------------------------------------------------------------------
indice_ponderado <- indice_deficit %>%
  mutate(
    puntaje = 3 * d_registro + 2 * d_finalizacion + 1 * d_part_time,
    # El índice ponderado: cada déficit entra multiplicado por su peso

    deficit_ponderado = factor(
      case_when(puntaje == 0        ~ "Sin déficit",
                puntaje %in% c(1,2) ~ "Déficit simple",
                puntaje %in% c(3,4) ~ "Déficit moderado",
                puntaje >= 5        ~ "Déficit severo"),
      levels = c("Sin déficit", "Déficit simple",
                 "Déficit moderado", "Déficit severo")))

indice_ponderado %>%
  group_by(deficit_ponderado) %>%
  summarise(poblacion = sum(PONDERA), .groups = "drop") %>%
  mutate(porcentaje = round(poblacion / sum(poblacion) * 100, 1))

